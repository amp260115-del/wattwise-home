# WattWise Home

WattWise Home is a React + TypeScript + Vite household energy dashboard. This migration keeps the existing AppDeploy site unchanged and moves the AI chat API to a Netlify Function.

## Requirements

- Node.js 20 or newer
- An OpenAI API key for the AI assistant (API billing is separate from a ChatGPT subscription)

## Run the frontend locally

```bash
npm install
npm run dev
```

The AI endpoint is hosted as a Netlify Function, so the chat feature will not work with plain `vite` dev server alone unless you also run the Netlify CLI (`npx netlify dev`) after configuring `OPENAI_API_KEY` in your local environment. Never commit your real key.

## Publish using GitHub + Netlify

1. Create a new GitHub repository named `wattwise-home`.
2. Upload the contents of this folder (not the ZIP file itself) to the repository. Do not upload `.env` files or API keys.
3. In Netlify, choose **Add new site → Import an existing project**, connect GitHub, and select the repository.
4. Build settings are defined in `netlify.toml`: build command `npm run build`, publish directory `dist`.
5. In Netlify site settings, add environment variable `OPENAI_API_KEY` with your secret API key. Optionally set `OPENAI_MODEL` to `gpt-4o-mini`. Redeploy after saving the variable.
6. Open the deployed URL and test the dashboard and AI chat.

## Google Search / SEO setup

Basic SEO files are included: page title and description, social-sharing metadata, WebApplication structured data, `public/robots.txt`, and `public/sitemap.xml`.

**Before publishing:** open `public/sitemap.xml` and replace `YOUR-SITE-NAME` with your actual Netlify subdomain (for example, `my-wattwise-site.netlify.app`). Then uncomment and update the `Sitemap:` line in `public/robots.txt` to use that same full URL. Do not leave the placeholder in a live deployment. If you later connect a custom domain, update the sitemap URL to that domain and redeploy.

After deployment, submit `https://YOUR-SITE-NAME.netlify.app/sitemap.xml` in [Google Search Console](https://search.google.com/search-console/), using your actual domain. You may need to verify ownership first. Google indexing is not instant or guaranteed; it can take days or longer, and SEO metadata alone cannot guarantee that a site appears for every search. Keep the site publicly accessible and avoid login walls on pages you want indexed.

## AI security notes

The API key is read only on the server-side Netlify Function. It is not included in frontend code. Do not paste it into `src/`, commit it to GitHub, or share it in chat. Configure usage limits and billing alerts in your OpenAI API account.

## Original app

The existing AppDeploy site is not modified by these migration files.

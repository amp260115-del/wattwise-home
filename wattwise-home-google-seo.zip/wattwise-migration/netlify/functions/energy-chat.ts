import type { Handler } from "@netlify/functions";

const SYSTEM_PROMPT = `You are WattWise Energy Assistant. Answer clearly about household electricity bills, appliance watts and kWh, solar bill offsets, efficient settings, and general electrical safety. Use supplied estimates as estimates; never promise exact savings. Never advise opening live electrical equipment, bypassing breakers, unsafe wiring, or hazardous electrical work. For smoke, sparks, electric shock, or burning smells, tell the user to keep away and contact emergency services or a qualified electrician. Redirect unrelated questions to household energy topics. Use plain language.`;

export const handler: Handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: { Allow: "POST", "Content-Type": "application/json" }, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    console.error("OPENAI_API_KEY is not configured");
    return { statusCode: 503, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "The energy assistant is not configured yet. Please try again later." }) };
  }

  let input: { question?: unknown; context?: unknown };
  try { input = JSON.parse(event.body || "{}"); }
  catch { return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Invalid JSON request." }) }; }

  const question = typeof input.question === "string" ? input.question.trim() : "";
  if (!question) return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Please enter a question." }) };
  if (question.length > 2000) return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Please keep your question under 2,000 characters." }) };

  try {
    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: `User question: ${question}\nHousehold context supplied by the user: ${JSON.stringify(input.context ?? {})}` }
        ],
        max_tokens: 500,
        temperature: 0.35
      })
    });
    if (!upstream.ok) {
      const details = await upstream.text();
      console.error("OpenAI API request failed", upstream.status, details.slice(0, 500));
      return { statusCode: 503, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "The energy assistant is temporarily unavailable. Please try again shortly." }) };
    }
    const result = await upstream.json() as { choices?: Array<{ message?: { content?: string | null } }> };
    const answer = result.choices?.[0]?.message?.content?.trim();
    if (!answer) throw new Error("The AI provider returned an empty answer");
    return { statusCode: 200, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify({ answer }) };
  } catch (error) {
    console.error("energy-chat failed", error);
    return { statusCode: 503, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "The energy assistant is temporarily unavailable. Please try again shortly." }) };
  }
};
